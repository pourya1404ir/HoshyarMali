package ir.hoshyarmali.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF101C2B)
private val Teal = Color(0xFF249C9A)
private val Pale = Color(0xFFF3F6F8)
private const val SIGN_IN_URL = "https://oranussanaat.ir/accounts"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HoshyarApp() }
    }
}

private fun securePrefs(context: Context) = EncryptedSharedPreferences.create(
    context,
    "secure_login",
    MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
)

private fun archiveDir(context: Context): File = File(context.filesDir, "payroll_archive").apply { mkdirs() }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HoshyarApp() {
    val context = LocalContext.current
    var page by remember { mutableStateOf("home") }
    var selectedPdf by remember { mutableStateOf<File?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val importPdf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            withContext(Dispatchers.IO) {
                val name = "فیش-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())}.pdf"
                val target = File(archiveDir(context), name)
                context.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(target).use { output -> input.copyTo(output) } }
            }
            refresh++
        }
    }
    val files = remember(refresh) { archiveDir(context).listFiles()?.filter { it.extension.equals("pdf", true) }?.sortedByDescending { it.lastModified() } ?: emptyList() }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
    MaterialTheme(colorScheme = lightColorScheme(primary = Teal, secondary = Navy, background = Pale, surface = Color.White)) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = { Text(if (page == "portal") "سامانه فیش حقوقی" else if (page == "archive") "آرشیو فیش‌ها" else if (page == "viewer") "نمایش فیش حقوقی" else "هوشیار مالی", fontWeight = FontWeight.Bold) },
                    navigationIcon = { if (page != "home") IconButton(onClick = { page = if (page == "viewer") "archive" else "home" }) { Icon(Icons.Default.ArrowBack, "بازگشت") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White, navigationIconContentColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = page == "home", onClick = { page = "home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("خانه") })
                    NavigationBarItem(selected = page == "archive", onClick = { page = "archive" }, icon = { Icon(Icons.Default.Archive, null) }, label = { Text("آرشیو") })
                    NavigationBarItem(selected = page == "portal", onClick = { page = "portal" }, icon = { Icon(Icons.Default.CloudDownload, null) }, label = { Text("دریافت فیش") })
                }
            }
        ) { padding ->
            when (page) {
                "portal" -> PortalScreen(Modifier.padding(padding), onPrint = { printWebView(context, it) })
                "archive" -> ArchiveScreen(Modifier.padding(padding), files, onOpen = { selectedPdf = it; page = "viewer" }, onImport = { importPdf.launch(arrayOf("application/pdf")) }, onDelete = { it.delete(); refresh++ })
                "viewer" -> PdfScreen(Modifier.padding(padding), selectedPdf)
                else -> HomeScreen(Modifier.padding(padding), files.size, onPortal = { page = "portal" }, onArchive = { page = "archive" }, onImport = { importPdf.launch(arrayOf("application/pdf")) })
            }
        }
    }
    }
}

@Composable
private fun HomeScreen(modifier: Modifier, count: Int, onPortal: () -> Unit, onArchive: () -> Unit, onImport: () -> Unit) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(26.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("هوشیار مالی", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("مدیریت ساده و امن فیش‌های حقوقی", color = Color(0xFFD4E4E8))
                Spacer(Modifier.height(6.dp))
                Button(onClick = onPortal, colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Icon(Icons.Default.CloudDownload, null); Spacer(Modifier.width(8.dp)); Text("دریافت فیش حقوقی") }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("فیش‌های ذخیره‌شده", count.toString(), Icons.Default.Description, Modifier.weight(1f))
            StatCard("دسترسی", "آفلاین", Icons.Default.Lock, Modifier.weight(1f))
        }
        Text("دسترسی سریع", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        ActionCard("آرشیو فیش‌های حقوقی", "مشاهده و مدیریت فیش‌های قبلی", Icons.Default.Archive, onArchive)
        ActionCard("افزودن فایل PDF", "وارد کردن فیش ذخیره‌شده از گوشی", Icons.Default.FolderOpen, onImport)
        Text("برای دریافت فیش، وارد سامانه شوید و ماه و سال موردنظر را انتخاب کنید.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(icon, null, tint = Teal); Text(title, color = Color.Gray, fontSize = 12.sp); Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Navy) }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Teal, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp)); Column { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Color.Gray, fontSize = 12.sp) } }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun PortalScreen(modifier: Modifier, onPrint: (WebView) -> Unit) {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }
    var showCredentials by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf(securePrefs(context).getString("username", "") ?: "") }
    var password by remember { mutableStateOf(securePrefs(context).getString("password", "") ?: "") }
    var pageTitle by remember { mutableStateOf("در حال اتصال به سامانه...") }
    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("برای دریافت فیش، ماه و سال را در سامانه انتخاب کنید.", Modifier.weight(1f), fontSize = 11.sp, color = Color.DarkGray)
            IconButton(onClick = { showCredentials = true }) { Icon(Icons.Default.Settings, "تنظیمات ورود") }
            IconButton(onClick = { webView?.let(onPrint) }) { Icon(Icons.Default.Print, "چاپ / ذخیره PDF") }
        }
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { ctx -> WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadsImagesAutomatically = true
                settings.javaScriptCanOpenWindowsAutomatically = true
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                webChromeClient = WebChromeClient()
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, url: String) {
                        pageTitle = view.title ?: "سامانه اورانوس صنعت"
                        val u = securePrefs(ctx).getString("username", "") ?: ""
                        val p = securePrefs(ctx).getString("password", "") ?: ""
                        if (url.contains("/accounts/signin") && u.isNotBlank() && p.isNotBlank()) {
                            val js = "(function(){var a=document.querySelector('input[name=username]');var b=document.querySelector('input[name=password]');if(a)a.value=${org.json.JSONObject.quote(u)};if(b)b.value=${org.json.JSONObject.quote(p)};})();"
                            view.evaluateJavascript(js, null)
                        }
                    }
                }
                setDownloadListener(DownloadListener { url, _, contentDisposition, mimeType, _ ->
                    if (mimeType?.contains("pdf", true) == true || url.contains(".pdf", true)) {
                        android.widget.Toast.makeText(ctx, "لینک PDF شناسایی شد؛ از گزینه چاپ یا ذخیره مرورگر سامانه استفاده کنید.", android.widget.Toast.LENGTH_LONG).show()
                    }
                })
                loadUrl(SIGN_IN_URL)
                webView = this
            } },
            update = { webView = it }
        )
    }
    if (showCredentials) AlertDialog(
        onDismissRequest = { showCredentials = false },
        title = { Text("ذخیره اطلاعات ورود") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("اطلاعات در فضای خصوصی برنامه و به‌صورت رمزنگاری‌شده نگهداری می‌شود.", fontSize = 12.sp, color = Color.Gray)
            OutlinedTextField(username, { username = it }, label = { Text("نام کاربری") }, singleLine = true)
            OutlinedTextField(password, { password = it }, label = { Text("رمز عبور") }, singleLine = true)
        } },
        confirmButton = { TextButton(onClick = { securePrefs(context).edit().putString("username", username).putString("password", password).apply(); showCredentials = false; webView?.reload() }) { Text("ذخیره") } },
        dismissButton = { TextButton(onClick = { showCredentials = false }) { Text("انصراف") } }
    )
}

private fun printWebView(context: Context, webView: WebView) {
    val manager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
    val adapter = webView.createPrintDocumentAdapter("فیش-حقوقی")
    manager.print("فیش-حقوقی", adapter, PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(PrintAttributes.Resolution("pdf", "PDF", 300, 300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())
}

@Composable
private fun ArchiveScreen(modifier: Modifier, files: List<File>, onOpen: (File) -> Unit, onImport: () -> Unit, onDelete: (File) -> Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("افزودن PDF از گوشی") }
        Spacer(Modifier.height(12.dp))
        if (files.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Archive, null, tint = Teal, modifier = Modifier.size(48.dp)); Text("هنوز فیشی ذخیره نشده است", color = Color.Gray) } }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(files, key = { it.absolutePath }) { file ->
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Description, null, tint = Teal, modifier = Modifier.size(32.dp)); Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f).clickable { onOpen(file) }) { Text(file.name, fontWeight = FontWeight.SemiBold); Text("${file.length() / 1024} کیلوبایت", color = Color.Gray, fontSize = 11.sp) }
                        IconButton(onClick = { onOpen(file) }) { Icon(Icons.Default.FolderOpen, "نمایش") }
                        IconButton(onClick = { onDelete(file) }) { Icon(Icons.Default.Delete, "حذف", tint = Color(0xFFB44B4B)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfScreen(modifier: Modifier, file: File?) {
    var pages by remember(file) { mutableStateOf<List<Bitmap>>(emptyList()) }
    var error by remember(file) { mutableStateOf<String?>(null) }
    LaunchedEffect(file) {
        pages = emptyList(); error = null
        if (file == null) return@LaunchedEffect
        withContext(Dispatchers.IO) {
            try {
                val fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                PdfRenderer(fd).use { renderer ->
                    val list = mutableListOf<Bitmap>()
                    for (i in 0 until renderer.pageCount) {
                        renderer.openPage(i).use { page ->
                            val bitmap = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            list.add(bitmap)
                        }
                    }
                    pages = list
                }
            } catch (e: Exception) { error = "نمایش این فایل ممکن نیست: ${e.localizedMessage}" }
        }
    }
    Column(modifier.fillMaxSize().background(Color(0xFFE7EAED)).padding(8.dp)) {
        if (error != null) Text(error!!, color = Color.Red)
        if (pages.isEmpty() && error == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Teal) }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(pages) { bitmap -> Image(bitmap.asImageBitmap(), null, Modifier.fillMaxWidth().background(Color.White)) } }
    }
}
